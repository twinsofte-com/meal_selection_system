<?php
require_once 'db.php';

// Fetch report details
$sql = "SELECT DISTINCT date FROM attendance ORDER BY date DESC";
$result = $conn->query($sql);

if ($result === FALSE) {
    die('Error fetching data: ' . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Report</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            color: black;
            text-decoration: none;
            padding: 10px 15px;
            display: inline-block;
        }

        nav a:hover {
            background-color: #0056b3;
            border-radius: 5px;
            color: #fff;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
            text-align: center;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        li a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        li a:hover {
            text-decoration: underline;
        }

        p {
            text-align: center;
            font-size: 16px;
        }

        .footer {
            text-align: center;
            padding: 10px;
            background-color: #007bff;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
<header>
    <div class="container">
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
        </div>
        <h1>Register Staff</h1>
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="register.php" >Register Staff</a></li>
                <li><a href="download_qr.php">Download QR Codes</a></li>
                <li><a href="download_report.php" class="active">Download Report</a></li>
            </ul>
        </nav>
    </div>
</header>
    
    <main>
        <div class="container">
            <h2>Select a Date to Download Report</h2>
            <?php if ($result->num_rows > 0): ?>
                <ul>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <li>
                            <?php echo htmlspecialchars($row['date']); ?>
                            <a href="generate_report.php?date=<?php echo urlencode($row['date']); ?>">Download PDF</a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No reports available.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer class="footer">
        Powered by Twinsofte.com. All rights reserved.
    </footer>
</body>
</html>
