<?php
require_once 'db.php';

$today = date('Y-m-d');

// Count how many staff need breakfast
$breakfastQuery = "SELECT COUNT(*) AS breakfast_count FROM staff_meals WHERE meal_date = '$today' AND breakfast = TRUE";
$breakfastResult = mysqli_query($conn, $breakfastQuery);
$breakfastCount = mysqli_fetch_assoc($breakfastResult)['breakfast_count'];

// Count how many staff need lunch
$lunchQuery = "SELECT COUNT(*) AS lunch_count FROM staff_meals WHERE meal_date = '$today' AND lunch = TRUE";
$lunchResult = mysqli_query($conn, $lunchQuery);
$lunchCount = mysqli_fetch_assoc($lunchResult)['lunch_count'];

// Count how many staff need dinner
$dinnerQuery = "SELECT COUNT(*) AS dinner_count FROM staff_meals WHERE meal_date = '$today' AND dinner = TRUE";
$dinnerResult = mysqli_query($conn, $dinnerQuery);
$dinnerCount = mysqli_fetch_assoc($dinnerResult)['dinner_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/admin_style.css">
</head>
<body>
<header>
    <div class="container">
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
        </div>
        <h1>Register Staff</h1>
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php" class="active">Home</a></li>
                <li><a href="register.php" >Register Staff</a></li>
                <li><a href="download_qr.php">Download QR Codes</a></li>
                <li><a href="download_report.php">Download Report</a></li>
            </ul>
        </nav>
    </div>
</header>




    <div class="admin-container">
        <h1>Admin Dashboard</h1>

        <div class="dashboard-cards">
            <div class="card">
                <h3>Today's Breakfast Count</h3>
                <p><?php echo $breakfastCount; ?></p>
            </div>
            <div class="card">
                <h3>Today's Lunch Count</h3>
                <p><?php echo $lunchCount; ?></p>
            </div>
            <div class="card">
                <h3>Today's Dinner Count</h3>
                <p><?php echo $dinnerCount; ?></p>
            </div>
        </div>
    </div>
    <footer class="footer">
        Powered by Twinsofte.com. All rights reserved.
    </footer>
</body>
</html>
