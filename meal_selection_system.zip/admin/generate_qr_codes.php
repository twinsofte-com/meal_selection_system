<?php
require_once 'db.php';
require_once '../phpqrcode/qrlib.php';

// Set header for file download
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="staff_qrcodes.zip"');

// Create a new ZIP file
$zip = new ZipArchive();
$zip->open('php://output', ZipArchive::CREATE | ZipArchive::OVERWRITE);

// Fetch all staff members
$sql = "SELECT id FROM staff";
$result = $conn->query($sql);

if ($result === FALSE) {
    die("Error fetching staff data: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
    $staff_id = $row['id'];
    $qr_code_content = "http://localhost:8080/scan.php?staff_id=$staff_id";
    $qr_code_file = "qrcodes/qr_$staff_id.png";

    // Generate QR Code
    QRcode::png($qr_code_content, $qr_code_file);

    // Add QR Code to ZIP file
    if (file_exists($qr_code_file)) {
        $zip->addFile($qr_code_file, "qr_$staff_id.png");
        // Optionally, delete the QR code file after adding it to the ZIP
        unlink($qr_code_file);
    } else {
        echo "Failed to generate QR code for staff ID $staff_id\n";
    }
}

// Close ZIP file
$zip->close();

// Close database connection
$conn->close();
?>
