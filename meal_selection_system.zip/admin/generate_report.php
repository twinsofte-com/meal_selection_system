<?php
require_once 'db.php';
require_once '../fpdf/fpdf.php'; // Ensure the path to FPDF is correct

$date = date('Y-m-d'); // Set the date for today's report

// SQL query to fetch staff names, meal preferences, and whether the meal was received
$sql = "SELECT staff.name, 
               CONCAT(
                   IF(breakfast = 1, 'Breakfast, ', ''),
                   IF(lunch = 1, 'Lunch, ', ''),
                   IF(dinner = 1, 'Dinner, ', '')
               ) AS meal_preference,
               IF(mc.confirmed = 1, 'Yes', 'No') AS meal_received
        FROM staff_meals 
        JOIN staff ON staff.id = staff_meals.staff_id 
        LEFT JOIN meal_confirmation mc ON staff.id = mc.staff_id AND mc.meal_date = staff_meals.meal_date
        WHERE staff_meals.meal_date = '$date'";

$result = $conn->query($sql);

if ($result === FALSE) {
    die("Error fetching data: " . $conn->error);
}

// Create a new FPDF instance
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Title
$pdf->Cell(0, 10, 'Meal Preferences Report for ' . htmlspecialchars($date), 0, 1, 'C');
$pdf->Ln(10);

// Header
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(60, 10, 'Staff Name', 1);
$pdf->Cell(100, 10, 'Meal Preferences', 1);
$pdf->Cell(30, 10, 'Received', 1);
$pdf->Ln();

// Body
$pdf->SetFont('Arial', '', 10);
while ($row = $result->fetch_assoc()) {
    $meal_preference = rtrim($row['meal_preference'], ', '); // Remove trailing comma and space
    $pdf->Cell(60, 10, htmlspecialchars($row['name']), 1);
    $pdf->Cell(100, 10, htmlspecialchars($meal_preference), 1);
    $pdf->Cell(30, 10, htmlspecialchars($row['meal_received']), 1);
    $pdf->Ln();
}

// Output PDF
header('Content-Type: application/pdf');
header('Content-Disposition: attachment;filename="meal_report_' . $date . '.pdf"');
$pdf->Output();
exit();
?>
