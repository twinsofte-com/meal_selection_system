<?php
require_once '../phpqrcode/qrlib.php'; // Update path if necessary
require_once 'db.php';

// Handle search query
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Handle staff registration
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'])) {
    $name = trim($_POST['name']);

    if (!empty($name)) {
        // Check if staff member with the same name already exists
        $stmt = $conn->prepare("SELECT id FROM staff WHERE name = ?");
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = "A staff member with this name already exists.";
        } else {
            // Prepare and execute SQL query to insert new staff member
            $stmt = $conn->prepare("INSERT INTO staff (name) VALUES (?)");
            $stmt->bind_param('s', $name);

            if ($stmt->execute()) {
                $staff_id = $stmt->insert_id; // Get the newly inserted staff ID

                // Generate QR Code with the staff ID
                $qr_code_file = 'qrcodes/qr_' . $staff_id . '.png';
                $qr_code_data = 'http://localhost:8080/scan.php?staff_id=' . $staff_id; // Adjust the URL as needed
                QRcode::png($qr_code_data, $qr_code_file, QR_ECLEVEL_L, 4);

                // Update staff record with the QR code file path
                $stmt_update = $conn->prepare("UPDATE staff SET qr_code = ? WHERE id = ?");
                $stmt_update->bind_param('si', $qr_code_file, $staff_id);
                $stmt_update->execute();
                $stmt_update->close();

                $message = "Staff member registered successfully.";
            } else {
                $message = "Error: " . $conn->error;
            }

            $stmt->close();
        }
    } else {
        $message = "Please enter a staff name.";
    }
}

// Search for staff members
$sql = "SELECT id, name, qr_code FROM staff WHERE name LIKE ?";
$stmt = $conn->prepare($sql);
$searchTerm = "%$search%";
$stmt->bind_param('s', $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

// Handle deletion message
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Staff</title>
    <link rel="stylesheet" href="css/admin_style.css"> <!-- Ensure this path is correct -->
</head>
<body>
<header>
    <div class="container">
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
        </div>
        <h1>Register Staff</h1>
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="register.php" class="active">Register Staff</a></li>
                <li><a href="download_qr.php">Download QR Codes</a></li>
                <li><a href="download_report.php">Download Report</a></li>
            </ul>
        </nav>
    </div>
</header>

    
    <main>
        <div class="container">
            <h2>Register New Staff</h2>
            
            <!-- Registration Form -->
            <div class="regform">
                <form method="post" action="">
                    <label for="name">Staff Name:</label>
                    <input type="text" id="name" name="name" required>
                    <button type="submit">Register</button>
                </form>
            </div>
            
            <?php if (!empty($message)): ?>
                <p><?php echo $message; ?></p>
            <?php endif; ?>

            <h2>Staff List</h2>

            <!-- Search Form -->
            <div class="search-box">
                <form method="get" action="">
                    <input type="text" name="search" placeholder="Search by name" value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit">Search</button>
                </form>
            </div>

            <!-- Staff Table -->
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>QR Code</th>
                        <th>Download</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $staff_id = $row['id'];
                            $name = $row['name'];
                            $qr_code_file = $row['qr_code'];
                            $download_url = "download_qr.php?staff_id=$staff_id";
                            $edit_url = "edit.php?staff_id=$staff_id";
                            $delete_url = "delete.php?staff_id=$staff_id";
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($name) . "</td>";
                            echo "<td>";
                            if ($qr_code_file) {
                                echo "<img src='$qr_code_file' alt='QR Code' class='qr-image'>";
                            } else {
                                echo "No QR Code";
                            }
                            echo "</td>";
                            echo "<td>";
                            if ($qr_code_file) {
                                echo "<a href='$download_url' class='button' target='_blank'>Download QR Code</a>";
                            }
                            echo "</td>";
                            echo "<td>";
                            echo "<a href='$edit_url' class='button'>Edit</a>";
                            echo "</td>";
                            echo "<td>";
                            echo "<a href='$delete_url' class='button' onclick='return confirm(\"Are you sure?\")'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
