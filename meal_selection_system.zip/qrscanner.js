document.addEventListener('DOMContentLoaded', function() {
    const html5QrCode = new Html5Qrcode("reader");

    function onScanSuccess(decodedText, decodedResult) {
        document.getElementById('staff_id').value = decodedText.split('staff_id=')[1];
        document.getElementById('popup').style.display = 'flex';
    }

    function onScanFailure(error) {
        console.warn(`QR code scan error: ${error}`);
    }

    html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        onScanSuccess,
        onScanFailure
    ).catch(err => {
        console.error(`Failed to start QR code scanning: ${err}`);
    });

    // Ensure elements exist before attaching event listeners
    const mealForm = document.getElementById('mealForm');
    const closePopup = document.getElementById('closePopup');

    if (mealForm) {
        mealForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(this);
            fetch('qrscanner_process.php', { // Correct PHP script name
                method: 'POST',
                body: formData
            }).then(response => response.text())
              .then(data => {
                  alert(data);
                  document.getElementById('popup').style.display = 'none';
              })
              .catch(error => console.error('Error:', error));
        });
    }

    if (closePopup) {
        closePopup.addEventListener('click', function() {
            document.getElementById('popup').style.display = 'none';
        });
    }
});
