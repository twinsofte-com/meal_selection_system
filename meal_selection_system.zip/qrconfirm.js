document.addEventListener('DOMContentLoaded', function() {
    const html5QrCode = new Html5Qrcode("reader");

    function onScanSuccess(decodedText, decodedResult) {
        document.getElementById('staff_id').value = decodedText.split('staff_id=')[1];
        document.getElementById('popup').style.display = 'flex';
    }

    function onScanFailure(error) {
        console.warn(`QR code scan error: ${error}`);
    }

    html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        onScanSuccess,
        onScanFailure
    ).catch(err => {
        console.error(`Failed to start QR code scanning: ${err}`);
    });

    document.getElementById('confirmForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(this);
        fetch('confirm_meal_process.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              alert(data);
              if (data.includes("confirmed")) {
                  document.getElementById('popup').style.display = 'none';
              }
          })
          .catch(error => console.error('Error:', error));
    });

    document.getElementById('closePopup').addEventListener('click', function() {
        document.getElementById('popup').style.display = 'none';
    });
});
