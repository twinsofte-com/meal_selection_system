<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Meal Receipt</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ensure this path is correct -->
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="qrconfirm.js" defer></script>
</head>
<body>
<header>
    <div class="container">
        <h1><img src="img/logo.png" alt="Logo" style="height: 65px; vertical-align: middle;"> Confirm Meals</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="confirm_meal.php">Confirm Meals</a>
        </nav>
    </div>
</header>

    
    <main>
        <section id="scanner">
            <div class="container">
                <h2>Scan Your QR Code</h2>
                <div id="reader"></div>
            </div>
        </section>
        
        <div id="popup" class="popup-overlay">
            <div class="popup-content">
                <h3>Meal Confirmation</h3>
                <form id="confirmForm">
                    <input type="hidden" name="staff_id" id="staff_id">
                    <button type="submit">Confirm Receipt</button>
                    <button type="button" id="closePopup">Close</button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
