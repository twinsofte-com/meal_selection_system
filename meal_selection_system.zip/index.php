<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Scanner</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ensure this path is correct -->
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="qrscanner.js" defer></script>
</head>
<body>
<header>
    <div class="container">
        <h1><img src="img/logo.png" alt="Logo" style="height: 65px; vertical-align: middle;"> Attendance Scanner</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="confirm_meal.php">Confirm Meals</a>
        </nav>
    </div>
</header>

    
    <main>
        <section id="scanner">
            <div class="container">
                <h2>Scan Your QR Code</h2>
                <div id="reader"></div>
            </div>
        </section>
        
        <div id="popup" class="popup-overlay" style="display: none;">
            <div class="popup-content">
                <h3>Meal Preferences</h3>
                <form id="mealForm">
                    <p>Select your meal preferences:</p>
                    <label><input type="checkbox" name="preferences[]" value="Breakfast"> Breakfast</label><br>
                    <label><input type="checkbox" name="preferences[]" value="Lunch"> Lunch</label><br>
                    <label><input type="checkbox" name="preferences[]" value="Dinner"> Dinner</label><br>
                    <input type="hidden" name="staff_id" id="staff_id">
                    <button type="submit">Submit</button>
                    <button type="button" id="closePopup">Close</button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
